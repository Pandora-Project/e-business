import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './LoginPage.jsx';
import AuthCallback from './AuthCallback.jsx';
import Dashboard from './Dashboard.jsx';

function App() {
  return (
    <BrowserRouter>
      <h1>App Loaded</h1> {/* TEMP DEBUG */}
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/auth/callback" element={<AuthCallback />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
