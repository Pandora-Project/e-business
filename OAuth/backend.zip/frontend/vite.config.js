// vite.config.js
export default {
  server: {
    proxy: {
      '/auth': 'http://localhost:4000',
      '/api': 'http://localhost:4000'
    }
  }
}
